---
name: wiki
description: >-
  A wiki unificada de Eduardo Kiwel em
  /mnt/NAS/Sync/Documentos/Pessoal/Wiki/wiki/ é sua fonte de verdade para
  conhecimento técnico curado, estado real do ambiente, rotinas, decisões,
  projetos, procedimentos e orientações. Consulte-a antes de memória auxiliar,
  web ou conhecimento de treino sempre que a tarefa depender desses assuntos,
  mesmo sem menção explícita à wiki. Registre durante a própria tarefa toda
  criação, conhecimento durável, mudança de rotina ou orientação recebida:
  pesquise primeiro, atualize a página canônica existente (ou crie uma quando
  necessário), e mantenha wiki/index.md e wiki/log.md. O comando isolado `raw`
  dispara ingestão incremental apenas de fontes novas ou alteradas, preservando
  raw/ imutável.
---

# Wiki unificada: consultar e devolver

A wiki é o segundo cérebro persistente do usuário. Ela reúne em um único vault o
conhecimento técnico curado e o retrato operacional do ambiente do J.A.R.V.I.S.
O fluxo obrigatório é: consultar antes, verificar estado volátil ao vivo e
registrar de volta o resultado durável antes de concluir a tarefa.

## Fonte de verdade e caminhos

A política canônica é `sobre-a-wiki.md`; ela prevalece sobre qualquer instrução
antiga ou referência gerada.

```text
vault:   /mnt/NAS/Sync/Documentos/Pessoal/Wiki/wiki/
policy:  /mnt/NAS/Sync/Documentos/Pessoal/Wiki/wiki/sobre-a-wiki.md
pages:   /mnt/NAS/Sync/Documentos/Pessoal/Wiki/wiki/wiki/
index:   /mnt/NAS/Sync/Documentos/Pessoal/Wiki/wiki/wiki/index.md
log:     /mnt/NAS/Sync/Documentos/Pessoal/Wiki/wiki/wiki/log.md
raw:     /mnt/NAS/Sync/Documentos/Pessoal/Wiki/wiki/raw/
```

Este vault substitui as antigas Wiki-Devops e Wiki-Jarvis separadas. Não mantenha
duplicação entre vaults antigos nem tente sincronizar duas bases.

## Fluxo de consulta

1. Confirme que o NAS e o vault estão acessíveis. Se não estiverem, informe; nunca
   finja ter consultado.
2. Leia `sobre-a-wiki.md` e `wiki/index.md` antes de outras fontes.
3. Pesquise em `wiki/*.md` e abra de fato as páginas relevantes; siga
   `[[wiki-links]]` quando ajudar.
4. Cite somente páginas lidas, no formato `(wiki: nome-da-pagina)`.
5. Trate páginas com “estado conferido em <data>” como retrato datado. Antes de
   uma decisão operacional, confirme o estado real com as ferramentas adequadas.
6. Se a wiki não cobrir o assunto ou estiver desatualizada, para bibliotecas,
   frameworks, SDKs, APIs, CLIs ou serviços de nuvem use Context7; só depois use
   web ou conhecimento de treino. Separe claramente fonte interna de externa.
7. Se fontes discordarem, registre e explique a contradição em vez de escolher
   silenciosamente uma versão.

## Registro obrigatório durante a tarefa

Toda criação, conhecimento adquirido, mudança de rotina, correção, implantação,
decisão, procedimento validado, pegadinha ou orientação recebida deve ser
registrado antes do fim da própria tarefa.

1. Pesquise primeiro para evitar duplicatas.
2. Atualize a página canônica existente quando ela já cobrir o assunto. Crie uma
   página nova em minúsculas e hífens somente quando não houver página adequada.
3. Registre o estado final, motivo, procedimento e implicações futuras; não copie
   tentativa e erro, transcrição integral ou saída bruta.
4. Atualize `wiki/index.md`. Página nova exige uma linha descritiva; numa alteração
   relevante, ajuste também descrições de navegação que ficaram obsoletas.
5. Prependa/adicione em `wiki/log.md` uma entrada datada, preservando seu caráter
   append-only.
6. Releia os trechos alterados e confira links, datas, ausência de duplicação e
   consistência com o estado ao vivo.
7. Considere documentação parte do critério de conclusão: não encerre apenas
   oferecendo documentar depois.

Atualizar uma página existente com o que acabou de ser validado é fluxo normal.
Para uma página nova ou reescrita grande, alinhe com o usuário quando isso não
impedir o registro mínimo necessário.

## Formato de página

Siga o formato canônico quando criar páginas:

```markdown
# Título

**Summary**: Síntese curta.

**Sources**: Fontes usadas.

**Last updated**: YYYY-MM-DD

---

Conteúdo com headings claros e [[wiki-links]].

## Related pages

- [[pagina-relacionada]]
```

Páginas operacionais existentes podem ter estrutura própria; preserve o estilo
delas quando atualizar.

## Limites e segurança

- Nunca grave senhas, tokens, chaves privadas, cookies ou valores secretos.
- Quando uma credencial for relevante, registre apenas onde é administrada.
- Nunca modifique `raw/`; fontes originais são imutáveis.
- Não registre progresso efêmero, logs rotineiros, artefatos temporários ou saída
  bruta sem curadoria.
- Não trate memória auxiliar como substituta da wiki nem documentação como
  substituta de verificação ao vivo.
- Assunto claramente fora do domínio da wiki pode ser respondido normalmente.

## Comando isolado `raw`

Quando a mensagem do usuário for somente `raw`:

1. Verifique `raw/` incrementalmente.
2. Processe apenas fontes novas ou alteradas.
3. Ignore fontes já processadas e inalteradas, sem relê-las integralmente.
4. Preserve todos os arquivos de `raw/` sem alteração.
5. Atualize páginas canônicas, `wiki/index.md` e `wiki/log.md` quando houver
   mudanças.
6. Peça esclarecimento somente diante de ambiguidade material, conteúdo delicado
   ou risco de registrar segredos.
