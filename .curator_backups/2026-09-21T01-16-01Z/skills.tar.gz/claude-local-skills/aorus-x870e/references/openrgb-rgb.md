# RGB / ARGB — OpenRGB e o controlador IT5711

## Resumo

O OpenRGB está **deliberadamente fixado em `1.0rc2-6.1`** no PCL, via `IgnorePkg` em
`/etc/pacman.conf`. Isso é intencional — **não é pacote desatualizado por descuido.**

Se aparecer um "openrgb: ignorando atualização" durante um `pacman -Syu`, está correto.
Não sugira remover o pin sem antes ler o motivo abaixo.

## Por que o pin existe

O upgrade pro `1.0rc3` (2026-07-08) **mudou o layout de zonas do controlador IT5711** da placa:
de 4 zonas para 6 — `LED_C` foi dividido em `LED_C` + `I/O Cover` + `Chipset Accent`.

Essa mudança invalida o `sizes.ors` e **zera os tamanhos das zonas ARGB**. Com as zonas em
tamanho 0, o usuário perde o controle dos headers endereçáveis — na prática o RGB dos
periféricos ligados nos headers ARGB morre. O rollback pro rc2 restaurou os **40 LEDs** do
`ARGB_V2_2` automaticamente, via o `sizes.ors` antigo.

## Estado configurado

- Pacote: `openrgb` **1.0rc2-6.1**, em `IgnorePkg` no `/etc/pacman.conf`
  (junto de `nvidia-dkms` e `refind` — ver a memória `bootloader-refind`).
- Autostart: `openrgb --startminimized --profile Def`
- `ARGB_V2_2` = **40 LEDs**

## Se um dia for atualizar pro rc3+

Não é impossível, só exige reconfiguração manual — o pin existe pra evitar a surpresa, não porque
o rc3 seja quebrado:

1. Atualizar o pacote (tirar do `IgnorePkg`).
2. Redimensionar as zonas ARGB na GUI: **`ARGB_V2_2` = 40 LEDs**.
3. **Salvar o perfil `Def` de novo** — senão o autostart carrega o perfil velho e as zonas voltam a zerar.

Depois de qualquer mudança, confira que o perfil `Def` ainda carrega certo no boot, já que é o que
o autostart usa.

## Não confunda com as fans

O **IT5711** (RGB) e o **IT8696E**/**IT87952E** (fans) são chips ITE diferentes, com drivers e
softwares diferentes, na mesma placa. Nomes parecidos, problemas independentes: mexer no `it87`
não afeta o RGB, e o OpenRGB não tem nada a ver com o CPU_FAN não aparecer no CoolerControl.

O RGB das fans **Lian-Li** também não passa pelo OpenRGB desta placa — elas têm controlador próprio
e software de terceiro.
