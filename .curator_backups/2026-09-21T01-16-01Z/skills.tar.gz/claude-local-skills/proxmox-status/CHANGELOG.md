# Changelog do ambiente Proxmox

Histórico datado de mudanças reais no ambiente — não da skill em si. Mais recente no topo.
Registre o **motivo**, não só o valor: o valor já está em `state/`.

Formato:

```markdown
## AAAA-MM-DD
- **Escopo (guest/área)** — o que mudou. Motivo: por quê.
```

---

## 2026-07-29
- **Skill `proxmox-status` criada** — estado completo documentado a partir da coleta de
  2026-07-28 23:30. Motivo: evitar redescobrir o parque inteiro por SSH a cada sessão e não
  repetir decisões ruins por desconhecer as armadilhas do ambiente.

## 2026-07-28
- **Jobs de backup desabilitados** (`enabled 0` nos dois, `jobs.cfg` às 23:18). Motivo: a execução
  das 02:00 levou ~10 h, falhou em cascata (VM 100, CT 118, CT 120) e deixou o host lento o dia
  inteiro. Decisão de pausar até redesenhar a estratégia. → `issues.md` #1
- **Locks de backup liberados nos CTs 120 (Pangolin) e 121 (Pihole)** via `pct unlock`. Motivo:
  ficaram travados após a falha do job das 02:00, bloqueando shutdown/start dos containers.
- **`ksmtuned` reconfigurado** — `KSM_THRES_COEF` de 20 % para 30 % (limiar de 12,8 GB → 19,2 GB),
  daemon reiniciado. Motivo: KSM nunca ativava porque a memória livre não chegava a cair abaixo do
  limiar antigo. Após a mudança, KSM ativou e deduplicou ~494 MiB. Backup do config original
  preservado. → `services.md`
- **VM 116 (Jarvis) e VM 100 (TrueNAS) reiniciadas** (~23:14–23:17). Contexto: sessão de
  diagnóstico de memória.

## 2026-07-26
- **Última execução de backup completa** — cobriu todos os guests. As execuções de 27 e 28/07 foram
  parciais.

## 2026-05-15
- **Último backup da VM 103 (BackupServer)** — `vzdump-qemu-103-2026_05_15-03_00_01.vma.zst` em
  `Backup_VMs`. Desde então o job dedicado a ela está desabilitado. → `issues.md` #2

---

### Antes de 2026-07-28

O histórico anterior não foi reconstruído. Datas conhecidas por artefatos:

- **2022-04-26** — VM 109 (Hassio) criada (`ctime=1651025385`). É a VM mais antiga do parque.
- **2025-10-15** — VM 114 (W11) criada (`ctime=1760568242`).
- **2025-10-28** — template VM 1000 (rockyt) criado (`ctime=1761618469`).
- **2025-12-12** — VMs 101 (Docker), 116 (Jarvis), 124 (Immich), 126 (K3s) e template 2000 criados
  (`ctime=1765545438` — mesmo timestamp, provavelmente uma leva de provisionamento).
- Guests removidos em algum momento (só restam backups órfãos): CT 119, CT 125, CT 127, VM 113,
  VM 115, e os IDs 123 e 126 foram reaproveitados trocando de tipo (VM→LXC e CT→VM).
