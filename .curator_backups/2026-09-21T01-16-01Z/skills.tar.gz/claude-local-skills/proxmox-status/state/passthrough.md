# Passthrough de hardware e nobreak (NUT)

**Verificado em:** 2026-07-28

## Tabela consolidada de passthrough

| # | Dispositivo | Tipo | Identificador | Destino | Configuração |
|---|---|---|---|---|---|
| 1 | **Intel UHD Graphics** (AlderLake-S GT1) | PCIe / GPU | `0000:00:02.0` (`8086:4680`) | **VM 124 — Immich** | `hostpci0: 0000:00:02,rombar=0,pcie=1` · driver `vfio-pci` · IOMMU grupo 0 (isolado) |
| 2 | **Netac NVMe SSD 1 TB** | Bloco NVMe | `nvme-Netac_NVMe_SSD_1TB_AA210602901000001566` | **VM 124 — Immich** | `scsi1`, `discard=on`, `iothread=1`, `ssd=1`, `backup=0` |
| 3 | **HGST HUS724040ALE641 4 TB ×6** | Bloco SATA | `A11HY4N4`, `RA5G2AGS`, `PN1334RA5G29OA`, `A11HY3LN`, `PN1334RA5G2A0Y`, `PN2334RA5G29M6` | **VM 100 — TrueNAS** | `scsi1`–`scsi6`, `backup=0`, `serial=` preservado |
| 4 | **Seagate ST1000LM024 1 TB** | Bloco SATA | `ata-ST1000LM024_HN-M101MBB_S32HJ9CG901518` | **VM 103 — BackupServer** | `scsi1`, `backup=0` — hospeda o datastore PBS `Bkp1tb` |
| 5 | **`/dev/net/tun`** | Char device | major 10, minor 200 | **CT 117 — nginx/NPM** | `lxc.cgroup2.devices.allow: c 10:200 rwm` + `lxc.mount.entry` |
| 6 | **Bind mount NFS** `/net/192.168.1.11/mnt/tank/Kiwel` | Filesystem | autofs do host | **CT 118 — Filebrowser** | `mp0: …,mp=/mnt/nas` |

**Não há nenhum passthrough USB** (`usb0`…`usbN`) configurado em VM alguma.

### Por que o passthrough da iGPU funciona limpo

O grupo IOMMU 0 contém **apenas** a iGPU — sem ACS override, sem `pcie_acs_override` no cmdline,
sem softdep de vfio em `modprobe.d`. O PVE liga `vfio-pci` ao dispositivo no start da VM 124.
`rombar=0` + `pcie=1` é a combinação correta para iGPU em máquina q35 com OVMF.

Consequência: **enquanto a VM 124 estiver ligada, a iGPU não está disponível para o host.** O
console de vídeo do host usa a Quadro K600.

### Cuidados ao mexer nos discos passados

Os discos vão por `/dev/disk/by-id/...` com `serial=` explícito — isso é o que permite ao ZFS do
TrueNAS identificá-los de forma estável mesmo se a ordem de `/dev/sdX` mudar. **Preserve o
`serial=` ao editar qualquer um desses `scsiN`.** Trocar por `/dev/sdX` quebraria o pool na
primeira mudança de enumeração.

Todos têm `backup=0`, então o vzdump só copia o disco raiz das VMs — correto e proposital.

## Nobreak (UPS) — não é passthrough

> **O nobreak NÃO é passado para nenhuma VM ou container.** É gerenciado **pelo host**, via NUT
> em modo servidor de rede. Se alguém perguntar "qual VM tem a porta USB do nobreak", a resposta
> é: nenhuma.

Dispositivos USB presentes no host (é tudo o que existe no barramento):

```
Bus 001 Device 001: ID 1d6b:0002  Linux Foundation 2.0 root hub
Bus 001 Device 002: ID 0483:5740  STMicroelectronics Virtual COM Port   ← o nobreak
Bus 002 Device 001: ID 1d6b:0003  Linux Foundation 3.0 root hub
```

O nobreak se apresenta como conversor serial STM32 (classe CDC-ACM, driver `cdc_acm`) e aparece
como **`/dev/ttyACM0`**. O NUT fala protocolo serial (`blazer_ser`), não HID USB — por isso passar
como dispositivo USB para uma VM não faria sentido. O acesso é distribuído pela rede: `upsd`
escuta em `0.0.0.0:3493` e qualquer host da LAN pode consultar como cliente NUT.

### Modelo e estado

| Campo | Valor |
|---|---|
| Fabricante / Modelo | **TS Shara** — `TS -222 231016` / `Senoid 18` (TSSHARA 1800) |
| Tipo | Offline / line-interactive |
| Firmware | `V010101058` |
| Conexão | USB → CDC-ACM → **`/dev/ttyACM0`** |
| Driver NUT | `blazer_ser` (v2.8.1, protocolo interno 1.60) |
| **Status (2026-07-28)** | **`OL` — em rede elétrica, normal** |
| Carga da bateria | 100 % · 27,40 V (nominal 24 V, alta 26,0 V, baixa 20,8 V) |
| Entrada | 224,0 V @ 60,0 Hz |
| Saída | 113,0 V |
| **Carga do nobreak** | **14 %** — folga confortável para o parque atual |
| Temperatura | 20,0 °C · Beeper habilitado |

### Configuração NUT

**`/etc/nut/nut.conf`** — `MODE=netserver` (o host é o servidor NUT da LAN)

**`/etc/nut/ups.conf`**
```ini
pollinterval = 1
maxretry = 1
offdelay = 120
ondelay = 240

[shara]
driver = blazer_ser
port = /dev/ttyACM0
desc = "TSSHARA 1800"
synchronous = auto
```

**`/etc/nut/upsd.conf`** — `LISTEN 0.0.0.0 3493`

**`/etc/nut/upsd.users`** — contas `upsadmin` (master, `SET`/`FSD`, `instcmds ALL`) e `upsuser`
(slave). ⚠️ **ambas com a senha padrão `nut`**, e o `upsd` escuta em toda a rede. Ver `issues.md` #17.

**`/etc/nut/upsmon.conf`** (pontos-chave)
```
RUN_AS_USER root
MONITOR shara@localhost 1 upsadmin <senha> master
SHUTDOWNCMD "/sbin/shutdown -h +0"
NOTIFYCMD  /usr/sbin/upssched
POLLFREQ 4        POLLFREQALERT 2
DEADTIME 24       MAXAGE 24       HOSTSYNC 15
POWERDOWNFLAG /etc/killpower
FINALDELAY 5      RBWARNTIME 43200      NOCOMMWARNTIME 600
```
Todos os eventos (ONLINE, ONBATT, LOWBATT, FSD, COMMOK, COMMBAD, SHUTDOWN, NOCOMM) disparam
`SYSLOG+WALL+EXEC`; REPLBATT e NOPARENT ficam em `SYSLOG+WALL`.

### Política de desligamento

**`/etc/nut/upssched.conf`**
```
CMDSCRIPT /etc/nut/shutdown.sh
PIPEFN /etc/nut/upssched.pipe
LOCKFN /etc/nut/upssched.lock

AT ONBATT   * START-TIMER shutdown_onbatt 120    # 2 min na bateria → desliga
AT ONBATT   * EXECUTE     info_onbatt
AT ONLINE   * CANCEL-TIMER shutdown_onbatt       # energia voltou → cancela
AT ONLINE   * EXECUTE     ups-back-on-power
AT LOWBATT  * EXECUTE     shutdown_lowbatt       # bateria baixa → desliga imediato
AT REPLBATT * EXECUTE     replace_batt
```

**Resumo:** queda de energia por mais de 120 s → desligamento ordenado do host via
`/etc/nut/shutdown.sh`. Bateria baixa dispara desligamento imediato, independente do temporizador.

Arquivos auxiliares em `/etc/nut/`: `shutdown.sh` (851 B) e `upssched-cmd` (449 B), ambos `0755`.

**Serviços:** `nut-server` ativo · `nut-monitor` ativo · `nut-driver-enable` inativo (normal).
