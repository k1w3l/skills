# Agenda (Stalwart)

Fonte da verdade: Stalwart. Nunca grave a App Password. Nunca fale com Google para criar evento.

Comando: `python3 ~/.hermes/scripts/calendar_ssh.py <args>`

- Hoje: `today`
- Semana: `week`
- Livre?: `freebusy --start 2026-08-22T14:00:00 --end 2026-08-22T15:00:00`
- Criar: `create --title '…' --start LDT --end LDT`
- Alterar/cancelar: `update ID …` / `delete ID`
- Timezone: America/Sao_Paulo. LDT sem Z.

Se stdout tiver `"error":"conflict"`, ofereça outro horário com os `busy`.
Se SSH falhar, diga que o Stalwart/mailagent está inacessível; não invente a agenda.
