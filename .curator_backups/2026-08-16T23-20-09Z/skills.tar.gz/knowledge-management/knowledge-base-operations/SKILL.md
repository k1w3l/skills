---
name: knowledge-base-operations
description: >-
  Operar e manter bases de conhecimento pessoais ou técnicas como fonte de verdade:
  consultar antes de responder, verificar estado operacional volátil, atualizar páginas
  canônicas, registrar mudanças, reconciliar edições concorrentes e preservar proveniência.
  Use sempre que uma tarefa consultar ou modificar wiki, vault Obsidian, runbook,
  documentação operacional, índice, changelog/log de conhecimento ou segundo cérebro —
  inclusive quando a documentação não for citada explicitamente, mas a resposta depender
  do estado documentado do ambiente.
---

# Knowledge Base Operations

Use a base como memória curada, não como depósito de transcrições. O objetivo é fazer o
conhecimento compor entre sessões sem transformar retratos antigos em falsas certezas.

Quando trabalhar na wiki pessoal do Sr. Kiwel, leia primeiro
`references/kiwel-wiki.md`; ele contém caminhos, regras locais e a sequência de manutenção.
A diretriz canônica do próprio vault prevalece sobre esta skill.

## Consulta antes de responder

1. Abra a diretriz da base e seu índice.
2. Pesquise páginas relevantes e leia o conteúdo real; não resuma de memória.
3. Siga links internos quando esclarecem conceito, dependência ou estado local.
4. Cite apenas páginas efetivamente lidas.
5. Se a base cobrir só parte da pergunta, separe claramente o que vem dela do que vem de
   documentação externa.
6. Para bibliotecas, APIs e ferramentas mutáveis, confirme em documentação oficial atual.

## Estado operacional volátil

IP, estado de VM/container, portas, jobs, capacidade, versões e saúde de serviços envelhecem
rapidamente. Para esses fatos:

1. Use a wiki para localizar a entidade e a fonte autoritativa.
2. Consulte o sistema ao vivo por uma interface de leitura apropriada.
3. Diferencie endereço LAN do host, bridge/rede interna e IP de container/pod.
4. Responda com o valor confirmado e identifique o escopo.
5. Se a confirmação acrescentar ou corrigir conhecimento, atualize a página canônica com
   fonte, data e aviso de volatilidade.

Não atualize a data de verificação de um documento inteiro quando apenas um campo foi
confirmado; anote a verificação junto ao campo para não sugerir que todo o inventário foi
revalidado.

## Registro obrigatório

Quando a tarefa criar algo, adquirir conhecimento, mudar uma rotina ou receber uma orientação:

1. Pesquise antes para evitar duplicatas.
2. Atualize a página canônica existente; crie uma nova somente se não houver local adequado.
3. Registre estado final, motivo, procedimento, implicações e proveniência úteis no futuro.
4. Não grave tentativa e erro sem conclusão, logs rotineiros, saída bruta ou progresso efêmero.
5. Nunca grave segredos; registre somente onde a credencial é administrada.
6. Atualize índice e log conforme a diretriz da base.
7. Considere a documentação parte do critério de conclusão, não uma oferta opcional posterior.

## Escrita concorrente

Vaults sincronizados podem mudar entre leitura e patch por ação de outro agente, editor ou
processo de sincronização.

1. Releia o trecho-alvo imediatamente antes de cada edição.
2. Se o arquivo mudou, reconcilie a versão nova com a alteração pretendida; não force o texto
   antigo por cima.
3. Procure se outro processo já criou a seção, entrada de índice ou log pretendida.
4. Mescle conteúdo complementar e remova duplicações sem perder informação mais recente.
5. Corrija atribuições imprecisas: não diga “confirmado pelo usuário” quando a evidência veio
   de uma consulta ao vivo, por exemplo.
6. Depois da escrita, releia os trechos modificados e confirme consistência entre página,
   índice e log.

## Critérios de qualidade

- Uma entidade tem uma página canônica reconhecível.
- Fatos operacionais indicam fonte, escopo e data de confirmação.
- Retratos datados não são apresentados como estado atual sem verificação.
- Índice descreve a página atual, não uma versão antiga.
- Log é append-only e não contém entradas duplicadas para a mesma operação.
- Links internos conectam conceito e implementação sem copiar indiscriminadamente.
- A resposta ao usuário permanece direta; a manutenção da wiki ocorre nos bastidores.

## Pitfalls

- Não confunda IP do host com IP de bridge Docker, pod ou container.
- Não crie uma segunda seção só porque o título existente usa outra redação.
- Não use memória persistente como prova do estado atual.
- Não sobrescreva edição concorrente com um patch preparado sobre conteúdo antigo.
- Não declare toda a base “verificada hoje” após checar apenas um dado.
- Não encerre uma mudança relevante com “posso documentar se desejar”.
