---
name: wiki-jarvis
description: >-
  Segundo cérebro persistente do usuário em
  /mnt/NAS/Sync/Documentos/Pessoal/Wiki/Wiki-Jarvis/. Consulte esta wiki SEMPRE
  antes de pesquisar na web, Context7, outras wikis, documentos ou conhecimento
  externo. Quando a mensagem do usuário for o comando isolado `raw`, carregue esta
  skill e processe incrementalmente `Wiki-Jarvis/raw/`, ingerindo somente fontes
  novas ou alteradas e ignorando as já processadas que permanecem inalteradas. Use também de forma proativa para
  registrar conhecimento durável. Não grave segredos nem progresso efêmero.
---

# Wiki-Jarvis — segundo cérebro

Use `/mnt/NAS/Sync/Documentos/Pessoal/Wiki/Wiki-Jarvis/` como a memória documental ampla e durável do usuário. A wiki deve reduzir perguntas repetidas, preservar contexto e permitir que decisões e descobertas componham ao longo do tempo.

Esta skill tem duas responsabilidades inseparáveis:

1. **Consultar primeiro:** procurar conhecimento existente antes de recorrer a qualquer fonte externa.
2. **Fechar o ciclo:** registrar automaticamente conhecimento novo que tenha valor futuro.

## Comando `raw`

Quando a mensagem do usuário for exatamente `raw` — comando isolado, sem outro pedido — trate-a como autorização permanente para executar a ingestão incremental das fontes em `/mnt/NAS/Sync/Documentos/Pessoal/Wiki/Wiki-Jarvis/raw/`. Processe somente arquivos novos ou alterados; fontes já ingeridas e inalteradas devem ser ignoradas, sem nova leitura ou validação de conteúdo.

1. Leia `sobre-a-wiki-jarvis.md`, `wiki/index.md` e `wiki/log.md` para carregar as diretrizes e o estado atual.
2. Faça inventário recursivo de todos os arquivos regulares em `raw/`. Nunca altere, mova ou exclua qualquer item dessa pasta.
3. Compare o inventário com páginas, citações e log existentes e, quando disponível, com hashes ou metadados registrados, para identificar fontes novas ou alteradas sem reler o conteúdo das fontes inalteradas.
4. Leia e processe integralmente somente os arquivos novos ou alterados. Ignore os que já foram ingeridos e permanecem inalterados. Evite recriar páginas ou duplicar conteúdo.
5. O comando `raw` já concede autorização para concluir o fluxo de ponta a ponta; não pare apenas para pedir confirmação genérica. Peça esclarecimento somente se houver ambiguidade material, conteúdo delicado ou risco de registrar segredos.
6. Crie uma página-resumo por fonte em `wiki/` e crie ou atualize as páginas conceituais necessárias. Use nomes em `kebab-case`, o formato definido nas diretrizes e citações `(source: caminho-relativo)` para afirmações factuais.
7. Atualize `wiki/index.md` com cada página nova ou mudança estrutural e acrescente a operação em `wiki/log.md`.
8. Verifique links, citações, ausência de segredos, cobertura de todas as fontes e preservação integral de `raw/`.
9. Ao terminar, informe arquivos novos/alterados processados, páginas criadas/atualizadas, quantidade de fontes inalteradas ignoradas, itens pendentes e verificações realizadas. Se nada mudou, não altere `wiki/index.md` nem `wiki/log.md`.

Se `raw` aparecer como termo dentro de outro pedido, não presuma que seja o comando: interprete-o pelo contexto normal.

## Ordem obrigatória de consulta

Antes de buscar em qualquer outro local:

1. Leia `wiki/index.md`.
2. Pesquise palavras-chave, sinônimos, nomes alternativos e siglas nos arquivos `wiki/*.md` da Wiki-Jarvis.
3. Leia as páginas relevantes e siga os links internos `[[nome-da-pagina]]` quando ajudarem.
4. Somente se a wiki não responder, ou responder parcialmente, consulte outras fontes na ordem mais apropriada à tarefa: wiki especializada do usuário, arquivos locais, documentação oficial/Context7, web e conhecimento geral.
5. Ao responder, indique as páginas realmente consultadas no formato `(Wiki-Jarvis: nome-da-pagina)`. Não invente citações.
6. Se houver conflito, prefira a informação mais recente e explícita. Aponte o conflito ao usuário quando ele for material.

A consulta vem antes da pesquisa externa, mas não substitui a verificação em fonte oficial quando o dado for volátil, como versões, preços, estado atual de serviços, documentação de API ou notícias.

## O que registrar proativamente

Ao longo da conversa e durante tarefas, grave sem exigir um pedido adicional quando descobrir algo com provável utilidade futura, por exemplo:

- fatos estáveis sobre o usuário, ambiente, infraestrutura, ferramentas e convenções;
- preferências, critérios, restrições e formas de trabalho;
- decisões e suas justificativas;
- arquitetura, configuração conceitual e relações entre sistemas;
- procedimentos reutilizáveis, soluções verificadas e armadilhas encontradas;
- contexto durável de projetos, responsabilidades e objetivos;
- sínteses de pesquisas, documentos e fontes que seriam custosas de reencontrar;
- correções feitas pelo usuário e conhecimento que evite repetir um erro.

Use este teste: **isto provavelmente evitará uma nova pesquisa, uma pergunta repetida ou uma decisão refeita no futuro?** Se sim, registre.

## O que não registrar

- senhas, tokens, chaves privadas, cookies, credenciais ou conteúdo de arquivos secretos;
- dados pessoais sensíveis sem necessidade clara;
- saídas brutas enormes, transcrições integrais ou cópias indiscriminadas;
- progresso temporário, tarefas efêmeras, logs operacionais rotineiros ou estados que perderão valor rapidamente;
- informação especulativa apresentada como fato;
- duplicatas: atualize uma página existente em vez de criar outra.

Quando uma credencial for relevante, registre apenas onde ela é administrada, nunca seu valor.

## Fluxo de gravação

1. **Pesquise antes de escrever.** Consulte `wiki/index.md` e procure páginas que já cubram o assunto.
2. **Escolha o destino.** Atualize a página canônica existente em `wiki/`. Crie uma nova apenas quando o tema merecer identidade própria.
3. **Nomeie de modo previsível.** Use arquivos Markdown em `kebab-case`, como `home-assistant.md` ou `preferencias-de-comunicacao.md`.
4. **Escreva conhecimento sintetizado.** Preserve o contexto necessário, a decisão, o motivo, a data quando ela importar e referências verificáveis.
5. **Conecte o conhecimento.** Use links Obsidian `[[pagina-relacionada]]` para relacionar páginas úteis.
6. **Registre proveniência.** Quando houver fonte, inclua URL, caminho de arquivo, comando verificado ou referência à conversa, sem expor segredos. Diferencie fato confirmado, decisão do usuário e hipótese.
7. **Atualize `wiki/index.md`.** Toda página nova deve aparecer no índice, agrupada por assunto, com uma descrição curta.
8. **Atualize `wiki/log.md`.** Acrescente uma entrada curta, datada, informando o que foi criado ou alterado e por quê.
9. **Evite reescrever o arquivo inteiro.** Leia primeiro e faça edição localizada com `patch` sempre que possível, preservando conteúdo alheio.
10. **Verifique.** Releia o trecho alterado, confirme links, ausência de segredos e consistência entre página, índice e log.

## Estrutura de página

Use este formato flexível, omitindo seções que não agreguem valor:

```markdown
# Título

Resumo curto do assunto e por que ele importa.

## Fatos e contexto

- Informação durável e objetiva.

## Decisões e preferências

- Decisão — justificativa e data, quando relevante.

## Procedimentos e aprendizados

- Passos reutilizáveis, verificações e armadilhas.

## Relacionados

- [[outra-pagina]]

## Fontes

- URL, caminho local ou referência verificável — consultada em AAAA-MM-DD.
```

Não force a estrutura quando uma nota curta for suficiente. Clareza, recuperação futura e baixa duplicação são mais importantes que uniformidade ornamental.

## Relação com outras memórias e wikis

- A Wiki-Jarvis é o ponto inicial de consulta geral e o segundo cérebro abrangente.
- **Sincronização obrigatória com a Wiki DevOps:** antes de qualquer gravação na Wiki-Jarvis, consulte `/mnt/NAS/Sync/Documentos/Pessoal/Wiki/Wiki-Devops/` (índice e páginas relacionadas ao assunto) e incorpore dados e aprendizados relevantes. Preserve a Wiki DevOps como fonte especializada, evite duplicação indiscriminada e registre na Wiki-Jarvis apenas a síntese, decisão, aprendizado ou ponte útil. Se houver conflito material, prefira a fonte mais recente e explícita e sinalize-o.
- WIKIs especializadas continuam sendo fontes de verdade em seus domínios. Consulte-as após a Wiki-Jarvis quando necessário e grave na Wiki-Jarvis apenas a síntese, decisão ou ponte relevante, evitando copiar bases inteiras.
- A memória nativa do agente pode guardar poucos fatos de altíssima frequência; a Wiki-Jarvis guarda contexto rico, relações, fontes e procedimentos.
- Skills guardam fluxos operacionais reutilizáveis. A Wiki-Jarvis deve registrar o conhecimento e apontar para a skill, não duplicar longas instruções sem necessidade.

## Comunicação

Não interrompa a tarefa apenas para anunciar cada gravação. Ao concluir, mencione de forma breve quais páginas da Wiki-Jarvis foram consultadas ou atualizadas quando isso for relevante. Se a gravação envolver informação delicada, ambígua ou potencialmente indesejada, peça confirmação antes de persistir.
